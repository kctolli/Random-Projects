package com.prove6.asynctask;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static String FILE = "numbers.txt";

    // This list will store the integers for our ListView
    private List<Integer> numberList;

    // This will help us connect the List to the ListView
    private ArrayAdapter<Integer> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // First create the List and the ArrayAdapter
        numberList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<Integer>(this, R.layout.my_list_item, numberList);

        // Now connect the ArrayAdapter to the ListView
        ListView listView = (ListView) findViewById(R.id.mainListView);
        listView.setAdapter(arrayAdapter);
    }

    public void onCreateClick(View view) {
        ProgressBar progressBar = findViewById(R.id.progressBar);

        // OK, here is where the changes happen. Instead of doing all the work
        // here, we will create a new AsyncTask and execute it. It will run
        // certain things on background threads, and at the appropriate time
        // publish progress on the main UI thread.

        // This could have been done with an anonymous class right here, and you'll
        // often see it done that way, but I chose to break it out into a separate
        // file to keep everything clean, and easy to follow.

        // Notice that we need to pass it references to "this" -- so it can have
        // a context object for things like accessing the file system and creating
        // toasts. And also, we can pass it a reference to the progressBar so it
        // can update it directly.
        CreateFileTask task = new CreateFileTask(this.getApplicationContext(), progressBar);

        // Calling the execute method is what begins the process of methods for
        // the AsyncTask
        task.execute(FILE);
    }

    public void onLoadClick(View view) {
        ProgressBar progressBar = findViewById(R.id.progressBar);

        // This is just the same as the CreateFileTask as far as the structure goes
        // and all the same comments apply. The only difference is that here we
        // are doing the loading...
        LoadFileTask task = new LoadFileTask(this.getApplicationContext(), progressBar, arrayAdapter);
        task.execute(FILE);
    }

    public void onClearClick(View view) {
        // Because this one is really efficient and doesn't have any calls
        // to expensive processes (e.g., database or Web service calls), we can
        // just leave it here and let it occur on the main UI thread. We don't
        // need to worry about doing it in a background thread.

        // Reset the progress bar
        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(0);

        // Clear the list
        arrayAdapter.clear();

        // Inform the user that things are cleared
        Toast.makeText(this, "Cleared", Toast.LENGTH_SHORT).show();
    }
}