package prove03;

/**
 * Created by lfalin on 1/14/17.
 */
class BYUITweet {
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    User user;
    String text;
}
