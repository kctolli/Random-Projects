/**
 * Different directions we might want to move.
 * @see Wolf
 */
public enum Direction {
    Left, Right, Up, Down;
}