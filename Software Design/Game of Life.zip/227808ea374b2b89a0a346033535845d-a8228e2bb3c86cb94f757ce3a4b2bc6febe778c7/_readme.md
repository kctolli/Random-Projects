# Game of Life - Teacher's Solution
This is _one_ way to solve the Game of Life assignment. It is not _the one and only_ way.