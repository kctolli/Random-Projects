# Activities and Intents

The following is _one_ way to have completed the assignment, it is not _the_ only way.